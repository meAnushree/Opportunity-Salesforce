<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>RiskIssue</name>
   <tag></tag>
   <elementGuidId>7842fe6c-5b1a-4c0b-9a0f-a217d788f475</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//label[text()='Risk Issue']/../../following-sibling::td//tr//span)[1]//select</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
