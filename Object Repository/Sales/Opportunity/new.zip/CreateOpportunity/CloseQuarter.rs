<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CloseQuarter</name>
   <tag></tag>
   <elementGuidId>ceb6500c-1192-4940-a8d8-bcbf9dabea4e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//label[text()='Expected Close Quarter']/..//following-sibling::td//following::span)[1]/child::input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
