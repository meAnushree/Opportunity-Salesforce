<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SearchAxUserName</name>
   <tag></tag>
   <elementGuidId>bbc5c6c7-94d3-46e5-82af-41804247ed16</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[text()='${Value}']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Sales/Common/IFrames/Frame2</value>
      <webElementGuid>13d62806-408c-44a5-a6a8-7f104b9e66d6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
