<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AddWonLostReasonBtn</name>
   <tag></tag>
   <elementGuidId>e6d616c7-6ceb-484b-9551-46337f5d1cf4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),'Won / Lost Reason')]//following::img[@title=&quot;Add&quot;][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
