<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AddIPTensilicaProductBtn</name>
   <tag></tag>
   <elementGuidId>dfa5382a-2311-44de-9bd3-410c2e111cd8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//label[text()='IP - Tensilica Product Category']/../following-sibling::td//a/img[@title='Add'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
