<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CashReceiptInQ0</name>
   <tag></tag>
   <elementGuidId>c3bb5953-1a06-4825-85b7-aa80414fcd65</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Cash Receipt in Q+0']/../following-sibling::td[@class=&quot;dataCol col02&quot;]/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
