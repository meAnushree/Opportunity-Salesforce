<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AddWonOrLossbtn</name>
   <tag></tag>
   <elementGuidId>bc16bab6-41a7-464b-8edf-59fad35e466a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//label[text()='Won / Lost Reason']/../../following-sibling::td//a/img[@title='Add'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
