<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>RequestedDeliveryDate</name>
   <tag></tag>
   <elementGuidId>aad90bc5-14fa-4e2d-ac07-1ac4c7360d81</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Requested Delivery Date']/../following-sibling::td[@class=&quot;dataCol col02&quot;]/span//input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
