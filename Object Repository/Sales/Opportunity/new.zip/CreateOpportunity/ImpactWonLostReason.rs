<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ImpactWonLostReason</name>
   <tag></tag>
   <elementGuidId>eb442c9b-ad3c-4c86-a2a1-d905e422c104</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Impact and Reason for Win/Loss']/../following-sibling::td//textarea</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
