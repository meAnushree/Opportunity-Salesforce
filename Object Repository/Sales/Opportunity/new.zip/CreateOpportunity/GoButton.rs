<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>GoButton</name>
   <tag></tag>
   <elementGuidId>163ae21d-26a2-4f76-a736-8687d0dc39e9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;pBody&quot;]//input[@type='submit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Sales/Opportunity/CreateOpportunity/frame1</value>
      <webElementGuid>41019818-3ad1-441d-bb74-1aeadd11826d</webElementGuid>
   </webElementProperties>
</WebElementEntity>
