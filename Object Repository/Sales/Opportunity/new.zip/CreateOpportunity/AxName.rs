<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AxName</name>
   <tag></tag>
   <elementGuidId>03ddf6e1-79c9-48a9-ad9e-9015c26b3c10</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[@type='text']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Sales/Opportunity/CreateOpportunity/frame1</value>
      <webElementGuid>737f6c68-4089-46a4-a599-b84b2df41650</webElementGuid>
   </webElementProperties>
</WebElementEntity>
