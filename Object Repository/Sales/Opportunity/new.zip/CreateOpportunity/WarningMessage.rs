<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WarningMessage</name>
   <tag></tag>
   <elementGuidId>8f030aaf-5018-4acc-8b33-7063072bdfe5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>IMAGE</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//td[text()='Warning Message']/following-sibling::td[1]/div/img</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
