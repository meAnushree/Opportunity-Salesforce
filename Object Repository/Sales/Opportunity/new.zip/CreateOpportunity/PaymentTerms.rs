<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PaymentTerms</name>
   <tag></tag>
   <elementGuidId>150f4e07-e219-45ee-8fe5-80abc0a06a15</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Payment Terms']/../following-sibling::td[@class=&quot;dataCol col02&quot;]//select</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
