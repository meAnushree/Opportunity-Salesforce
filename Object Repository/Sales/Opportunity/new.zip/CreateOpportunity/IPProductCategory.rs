<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IPProductCategory</name>
   <tag></tag>
   <elementGuidId>07616711-625b-4ff7-8ea3-4b8b8f5ee976</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='IP Product Category']/../following-sibling::td//table//select[@title='IP Product Category - Available']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
