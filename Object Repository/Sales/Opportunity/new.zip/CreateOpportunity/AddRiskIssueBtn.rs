<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AddRiskIssueBtn</name>
   <tag></tag>
   <elementGuidId>8c7f0f3a-6d19-4547-a584-fa38ef21cb66</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Risk Issue']/../../following-sibling::td//a/img[@title='Add']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
