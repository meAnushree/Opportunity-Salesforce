<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>OpportunityID</name>
   <tag></tag>
   <elementGuidId>0887bfc5-ba5a-4e78-85f9-76bde5913d7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[text()='Opportunity ID']//following-sibling::td/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
