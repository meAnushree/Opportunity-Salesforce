<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>EndProductSegment</name>
   <tag></tag>
   <elementGuidId>b2e1219f-24c4-4a88-b44a-6e1711805dc0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='End Product Segment']/../../following-sibling::td//table//select[@title=&quot;End Product Segment - Available&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
