<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>HwPlatform</name>
   <tag></tag>
   <elementGuidId>a5039361-f33f-4682-bc8c-9509a956f4b9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='HW Platform']/../following-sibling::td[@class=&quot;dataCol col02&quot;]//select</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
