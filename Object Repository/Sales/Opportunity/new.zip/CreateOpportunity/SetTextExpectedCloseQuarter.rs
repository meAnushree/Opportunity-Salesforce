<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SetTextExpectedCloseQuarter</name>
   <tag></tag>
   <elementGuidId>21b8d0ab-56ba-4d6f-ba0d-f9a60af8d1df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@type=&quot;text&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Sales/Common/IFrames/Frame1</value>
      <webElementGuid>455f8fc5-56f1-4ee8-9f7a-7349d6666fb5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
