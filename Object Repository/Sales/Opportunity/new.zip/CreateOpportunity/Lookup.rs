<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Lookup</name>
   <tag></tag>
   <elementGuidId>a207f30d-db7d-4d81-a3d2-93aff5abc6f0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;pBody&quot;]//input[@type='text']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Sales/Opportunity/CreateOpportunity/frame1</value>
      <webElementGuid>8283254a-50ba-4723-986c-2201eec0aa82</webElementGuid>
   </webElementProperties>
</WebElementEntity>
