<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AddEndProductSegmentBtn</name>
   <tag></tag>
   <elementGuidId>5ca2bbd5-b1c2-4a6a-8ff3-22ddb4c4e351</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//label[text()='End Product Segment']/../../following-sibling::td//a/img[@title='Add'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
