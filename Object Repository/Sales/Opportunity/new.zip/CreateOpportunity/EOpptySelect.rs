<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>EOpptySelect</name>
   <tag></tag>
   <elementGuidId>14c07888-7f0f-4228-a929-bac530ee9cd7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//tr[@class=&quot;headerRow&quot;]//following-sibling::tr/child::td[text()='${Value}'])[1]//preceding-sibling::th</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
