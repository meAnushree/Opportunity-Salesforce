<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LookupResult</name>
   <tag></tag>
   <elementGuidId>75bd09c1-9216-4772-b702-2dc20c69af74</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[@scope='row']//a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Sales/Opportunity/CreateOpportunity/Frame2</value>
      <webElementGuid>09eb73cc-15b0-4d8c-9b7a-7bcd6fbbf0e8</webElementGuid>
   </webElementProperties>
</WebElementEntity>
